
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'mjack',
  applicationName: 'amplifybranchtest',
  appUid: 'h2MqNzGLq03L1DHlr0',
  orgUid: 'b4856e35-1802-430b-afff-0fb21fcc46c6',
  deploymentUid: 'f983454f-5ae6-4868-a5b8-cb49055b6d46',
  serviceName: 'amplifyproject',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'amplifyproject-dev-function1', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}